import React from 'react';

function Contact() {
  return (
    <div className="Contact">
      <h2>Contact Us</h2>
      <p>This is the contact page.</p>
    </div>
  );
}

export default Contact;