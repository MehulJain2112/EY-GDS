import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return (
    <div className="Home">
      <h1>Welcome to EY</h1>
      <img src="/logo.png" alt="Company Logo" />
      <nav>
        <Link to="/login">Login</Link> | 
        <Link to="/signup">Signup</Link> | 
        <Link to="/about">About Us</Link> | 
        <Link to="/contact">Contact</Link>
      </nav>
    </div>
  );
}

export default Home;