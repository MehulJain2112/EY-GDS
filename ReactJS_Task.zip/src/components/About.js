import React from 'react';

function About() {
  return (
    <div className="About">
      <h2>About Us</h2>
      <p>This is the about us page.</p>
    </div>
  );
}

export default About;